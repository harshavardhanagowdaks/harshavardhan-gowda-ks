from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
import asyncio
import json
import logging
from backend.asr_engine import ASREngine
from backend.nlp_pipeline import NLPPipeline

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Engines
# We initialize them lazily or on startup to avoid long load times during import
asr_engine = None
nlp_pipeline = None

@app.on_event("startup")
async def startup_event():
    global asr_engine, nlp_pipeline
    logger.info("Loading ASR Engine...")
    asr_engine = ASREngine()
    logger.info("Loading NLP Pipeline...")
    nlp_pipeline = NLPPipeline()
    logger.info("Systems Loaded.")

@app.websocket("/ws/dictate")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    logger.info("Client connected")
    
    try:
        while True:
            # Receive data (audio chunk or control message)
            data = await websocket.receive()
            
            if "bytes" in data:
                audio_chunk = data["bytes"]
                # Process audio chunk
                # 1. ASR
                raw_text, is_final = asr_engine.process_audio(audio_chunk)
                
                if raw_text:
                    # Send raw update
                    await websocket.send_json({
                        "type": "raw",
                        "text": raw_text,
                        "is_final": is_final
                    })
                    
                    if is_final:
                        # 2. NLP Pipeline (only on final segments)
                        polished_text, metrics, diagnostics = nlp_pipeline.process(raw_text)
                        
                        await websocket.send_json({
                            "type": "polished",
                            "text": polished_text,
                            "metrics": metrics,
                            "diagnostics": diagnostics
                        })
            
            elif "text" in data:
                # Handle control messages (e.g., set tone)
                message = json.loads(data["text"])
                if message.get("type") == "set_tone":
                    tone = message.get("tone")
                    nlp_pipeline.set_tone(tone)
                    logger.info(f"Tone set to: {tone}")

    except WebSocketDisconnect:
        logger.info("Client disconnected")
    except Exception as e:
        logger.error(f"Error: {e}")
        await websocket.close()
