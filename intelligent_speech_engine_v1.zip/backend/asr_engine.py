import numpy as np
from faster_whisper import WhisperModel
import io
import logging
import torch

logger = logging.getLogger(__name__)

class ASREngine:
    def __init__(self, model_size="tiny.en", device="cpu", compute_type="int8"):
        logger.info(f"Initializing Whisper model: {model_size} on {device}")
        try:
            self.model = WhisperModel(model_size, device=device, compute_type=compute_type)
        except Exception as e:
            logger.error(f"Failed to load Whisper model: {e}")
            raise e
        
        self.audio_buffer = np.array([], dtype=np.float32)
        self.sample_rate = 16000
        # VAD / Chunking parameters
        self.silence_threshold = 0.01 # Simple energy based for now, can upgrade to webrtcvad
        self.min_chunk_duration = 2.0 # seconds
        self.last_process_time = 0

    def process_audio(self, audio_bytes):
        """
        Process raw audio bytes (float32, 16kHz, mono).
        Returns (text, is_final)
        """
        # Convert bytes to numpy array
        # Assuming input is sent as float32 bytes
        chunk = np.frombuffer(audio_bytes, dtype=np.float32)
        self.audio_buffer = np.concatenate((self.audio_buffer, chunk))
        
        # Simple VAD / End of speech detection
        # Check if buffer is long enough
        if len(self.audio_buffer) / self.sample_rate < 1.0:
            return None, False

        # Transcribe
        # We transcribe the whole buffer but only commit if we detect a pause or it's long enough
        segments, info = self.model.transcribe(
            self.audio_buffer, 
            beam_size=5, 
            language="en",
            vad_filter=True,
            vad_parameters=dict(min_silence_duration_ms=500)
        )
        
        text = " ".join([segment.text for segment in segments]).strip()
        
        # Logic to determine if "final"
        # For this simple implementation, we'll consider it final if we have a valid text 
        # and the buffer is getting long or we detect silence at the end.
        # Real-time streaming usually requires more complex overlapping logic.
        # Here we will simulate streaming by returning partials.
        
        is_final = False
        
        # If we have text and silence at the end of buffer
        # Energy of last 0.5s
        last_05s = self.audio_buffer[-int(0.5*self.sample_rate):]
        energy = np.sqrt(np.mean(last_05s**2))
        
        if len(self.audio_buffer) / self.sample_rate > 5.0 or (text and energy < self.silence_threshold):
            is_final = True
            self.audio_buffer = np.array([], dtype=np.float32) # Reset buffer after final
        
        return text, is_final
