import re
import time
import spacy
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
import logging
import torch

logger = logging.getLogger(__name__)

class NLPPipeline:
    def __init__(self):
        logger.info("Initializing NLP Pipeline...")
        
        # Load Spacy for basic NLP
        try:
            self.nlp = spacy.load("en_core_web_sm")
        except:
            logger.warning("Spacy model not found, downloading...")
            spacy.cli.download("en_core_web_sm")
            self.nlp = spacy.load("en_core_web_sm")

        # Load Grammar/Tone Model (T5-small or similar)
        # using a model fine-tuned for grammar correction
        self.model_name = "vennify/t5-base-grammar-correction" # Good balance, or t5-small
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        logger.info(f"Loading Grammar Model on {self.device}...")
        
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            self.model = AutoModelForSeq2SeqLM.from_pretrained(self.model_name).to(self.device)
        except Exception as e:
            logger.error(f"Failed to load T5 model: {e}")
            # Fallback to simple rules if model fails? Or crash?
            # Requirement says "Build... from scratch", so we should ensure it works.
            # We will assume internet is available for first run download.
            raise e

        self.current_tone = "Neutral"
        
        # Filler words list
        self.fillers = [
            "umm", "uhh", "uh", "um", "like", "you know", "sort of", "kind of", 
            "basically", "literally", "actually", "matlab", "i mean"
        ]

    def set_tone(self, tone):
        self.current_tone = tone

    def remove_fillers(self, text):
        # Case insensitive replacement
        # We use word boundaries \b to avoid replacing parts of words
        cleaned_text = text
        removed_words = []
        
        for filler in self.fillers:
            pattern = re.compile(r'\b' + re.escape(filler) + r'\b', re.IGNORECASE)
            matches = pattern.findall(cleaned_text)
            if matches:
                removed_words.extend(matches)
                cleaned_text = pattern.sub('', cleaned_text)
        
        # Clean up double spaces
        cleaned_text = re.sub(r'\s+', ' ', cleaned_text).strip()
        return cleaned_text, removed_words

    def remove_repetitions(self, text):
        # Simple repetition removal: "word word" -> "word"
        # "phrase phrase" -> "phrase"
        
        words = text.split()
        if not words:
            return text, []

        new_words = []
        removed_segments = []
        
        i = 0
        while i < len(words):
            word = words[i]
            # Check for single word repetition
            if i + 1 < len(words) and words[i+1].lower() == word.lower():
                removed_segments.append(words[i+1])
                new_words.append(word)
                i += 2
                continue
            
            # Check for 2-gram repetition
            if i + 3 < len(words):
                bigram = f"{words[i]} {words[i+1]}"
                next_bigram = f"{words[i+2]} {words[i+3]}"
                if bigram.lower() == next_bigram.lower():
                    removed_segments.append(next_bigram)
                    new_words.extend([words[i], words[i+1]])
                    i += 4
                    continue
            
            new_words.append(word)
            i += 1
            
        return " ".join(new_words), removed_segments

    def apply_grammar_and_tone(self, text):
        if not text:
            return text, "No changes"
            
        # Prepare input for T5
        # For grammar correction model, input is just the text usually.
        # If we want tone, we might need to prompt it if the model supports it.
        # Since we are using a specific grammar correction model, it might not support "Formalize:" prefix well.
        # But standard T5 does.
        # Let's try to frame it.
        
        input_text = f"grammar: {text}" 
        
        if self.current_tone == "Formal":
            # Heuristic: Grammar correction usually formalizes a bit.
            pass
        elif self.current_tone == "Concise":
            # We might post-process or use a summarization prefix if model supported it.
            pass
            
        input_ids = self.tokenizer.encode(input_text, return_tensors="pt").to(self.device)
        
        outputs = self.model.generate(
            input_ids, 
            max_length=128, 
            num_beams=4, 
            early_stopping=True
        )
        
        corrected_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        return corrected_text

    def process(self, raw_text):
        start_time = time.time()
        diagnostics = {
            "original": raw_text,
            "fillers_removed": [],
            "repetitions_removed": [],
            "grammar_changes": ""
        }
        
        # 1. Filler Removal
        text_no_fillers, fillers = self.remove_fillers(raw_text)
        diagnostics["fillers_removed"] = fillers
        
        # 2. Repetition Removal
        text_no_reps, reps = self.remove_repetitions(text_no_fillers)
        diagnostics["repetitions_removed"] = reps
        
        # 3. Grammar & Tone
        # Only run if we have enough text to warrant it
        if len(text_no_reps.split()) > 2:
            polished_text = self.apply_grammar_and_tone(text_no_reps)
        else:
            polished_text = text_no_reps
            
        diagnostics["grammar_changes"] = f"{text_no_reps} -> {polished_text}"
        
        end_time = time.time()
        pipeline_latency = (end_time - start_time) * 1000 # ms
        
        metrics = {
            "pipeline_latency": pipeline_latency
        }
        
        return polished_text, metrics, diagnostics
