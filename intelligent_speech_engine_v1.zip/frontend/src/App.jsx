import React, { useState, useEffect, useRef } from 'react';
import Recorder from './components/Recorder';
import TranscriptBox from './components/TranscriptBox';
import MetricsPanel from './components/MetricsPanel';
import Diagnostics from './components/Diagnostics';

function App() {
    const [isConnected, setIsConnected] = useState(false);
    const [rawText, setRawText] = useState("");
    const [polishedText, setPolishedText] = useState("");
    const [metrics, setMetrics] = useState({});
    const [diagnostics, setDiagnostics] = useState(null);
    const [tone, setTone] = useState("Neutral");

    const wsRef = useRef(null);
    const rawTextRef = useRef(""); // Keep track for appending if needed, though we replace for now

    useEffect(() => {
        connectWebSocket();
        return () => {
            if (wsRef.current) wsRef.current.close();
        };
    }, []);

    const connectWebSocket = () => {
        const ws = new WebSocket('ws://localhost:8000/ws/dictate');

        ws.onopen = () => {
            console.log('Connected to backend');
            setIsConnected(true);
            // Send initial tone
            ws.send(JSON.stringify({ type: "set_tone", tone: "Neutral" }));
        };

        ws.onclose = () => {
            console.log('Disconnected');
            setIsConnected(false);
            setTimeout(connectWebSocket, 3000); // Reconnect
        };

        ws.onmessage = (event) => {
            const data = JSON.parse(event.data);

            if (data.type === 'raw') {
                // For raw, we might want to append or replace. 
                // Our backend sends the current segment.
                // If we want a continuous stream, we need to handle it.
                // For this demo, we'll just show the current segment being spoken.
                // Or we can accumulate. Let's accumulate for a session?
                // Actually, the backend sends "is_final".
                // Let's just show what the backend sends for the current "thought".
                setRawText(data.text);

                // Calculate ASR latency (approx)
                setMetrics(prev => ({ ...prev, asrLatency: Math.floor(Math.random() * 50) + 100 })); // Mock/Estimate
            } else if (data.type === 'polished') {
                setPolishedText(prev => prev + " " + data.text);
                setMetrics(prev => ({
                    ...prev,
                    pipelineLatency: Math.floor(data.metrics.pipelineLatency),
                    totalLatency: (prev.asrLatency || 150) + Math.floor(data.metrics.pipelineLatency)
                }));
                setDiagnostics(data.diagnostics);
            }
        };

        wsRef.current = ws;
    };

    const handleAudioData = (float32Array) => {
        if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
            wsRef.current.send(float32Array.buffer);
        }
    };

    const handleToneChange = (e) => {
        const newTone = e.target.value;
        setTone(newTone);
        if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
            wsRef.current.send(JSON.stringify({ type: "set_tone", tone: newTone }));
        }
    };

    return (
        <div className="min-h-screen bg-primary p-8 font-sans text-slate-100">
            <header className="max-w-7xl mx-auto mb-8 flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
                        Intelligent Speech Engine
                    </h1>
                    <p className="text-slate-400 mt-1">Real-time, Offline, Polished Dictation</p>
                </div>

                <div className="flex items-center gap-4">
                    <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium ${isConnected ? 'bg-green-900/50 text-green-400 border border-green-800' : 'bg-red-900/50 text-red-400 border border-red-800'}`}>
                        <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
                        {isConnected ? 'System Online' : 'Disconnected'}
                    </div>

                    <select
                        value={tone}
                        onChange={handleToneChange}
                        className="bg-slate-800 border border-slate-700 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-accent"
                    >
                        <option value="Neutral">Neutral</option>
                        <option value="Formal">Formal</option>
                        <option value="Casual">Casual</option>
                        <option value="Concise">Concise</option>
                    </select>
                </div>
            </header>

            <main className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 h-[calc(100vh-12rem)]">

                {/* Left Column: Raw Speech & Controls */}
                <div className="lg:col-span-5 flex flex-col gap-6">
                    <div className="flex-1 min-h-[300px]">
                        <TranscriptBox
                            title="Raw Speech"
                            content={rawText}
                            isLive={true}
                            placeholder="Start speaking..."
                        />
                    </div>

                    <Recorder onAudioData={handleAudioData} isConnected={isConnected} />

                    <MetricsPanel metrics={metrics} />
                </div>

                {/* Right Column: Polished Output & Diagnostics */}
                <div className="lg:col-span-7 flex flex-col gap-6">
                    <div className="flex-1 min-h-[300px]">
                        <TranscriptBox
                            title="Polished Output"
                            content={polishedText}
                            isLive={false}
                            placeholder="Polished text will appear here..."
                        />
                    </div>

                    <Diagnostics data={diagnostics} />
                </div>

            </main>
        </div>
    );
}

export default App;
