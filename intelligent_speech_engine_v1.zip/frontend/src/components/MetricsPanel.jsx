import React from 'react';

const MetricCard = ({ label, value, unit }) => (
    <div className="bg-slate-800 p-4 rounded-lg border border-slate-700 flex flex-col items-center">
        <span className="text-slate-400 text-sm mb-1">{label}</span>
        <div className="text-2xl font-bold text-accent">
            {value} <span className="text-sm font-normal text-slate-500">{unit}</span>
        </div>
    </div>
);

const MetricsPanel = ({ metrics }) => {
    return (
        <div className="grid grid-cols-3 gap-4 mb-6">
            <MetricCard label="ASR Latency" value={metrics.asrLatency || 0} unit="ms" />
            <MetricCard label="Pipeline Latency" value={metrics.pipelineLatency || 0} unit="ms" />
            <MetricCard label="Total Latency" value={metrics.totalLatency || 0} unit="ms" />
        </div>
    );
};

export default MetricsPanel;
