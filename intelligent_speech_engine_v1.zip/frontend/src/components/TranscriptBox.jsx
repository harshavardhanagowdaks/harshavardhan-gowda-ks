import React from 'react';

const TranscriptBox = ({ title, content, isLive, placeholder }) => {
    return (
        <div className="flex flex-col h-full bg-secondary rounded-xl p-6 shadow-lg border border-slate-700">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-slate-200">{title}</h2>
                {isLive && <span className="flex h-3 w-3 relative">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                </span>}
            </div>
            <div className="flex-1 overflow-y-auto custom-scrollbar whitespace-pre-wrap text-lg leading-relaxed text-slate-300 font-medium">
                {content || <span className="text-slate-600 italic">{placeholder}</span>}
            </div>
        </div>
    );
};

export default TranscriptBox;
