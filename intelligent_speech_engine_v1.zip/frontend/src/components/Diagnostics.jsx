import React from 'react';

const Chip = ({ text, color }) => (
    <span className={`inline-block px-2 py-1 text-xs font-semibold rounded-full mr-2 mb-2 ${color}`}>
        {text}
    </span>
);

const Diagnostics = ({ data }) => {
    if (!data) return null;

    return (
        <div className="bg-slate-800 p-4 rounded-lg border border-slate-700 mt-6">
            <h3 className="text-sm font-bold text-slate-400 mb-3 uppercase tracking-wider">Diagnostics</h3>

            <div className="space-y-4">
                {data.fillers_removed && data.fillers_removed.length > 0 && (
                    <div>
                        <span className="text-xs text-slate-500 block mb-1">Fillers Removed</span>
                        <div className="flex flex-wrap">
                            {data.fillers_removed.map((word, i) => (
                                <Chip key={i} text={word} color="bg-red-900 text-red-200" />
                            ))}
                        </div>
                    </div>
                )}

                {data.repetitions_removed && data.repetitions_removed.length > 0 && (
                    <div>
                        <span className="text-xs text-slate-500 block mb-1">Repetitions Removed</span>
                        <div className="flex flex-wrap">
                            {data.repetitions_removed.map((word, i) => (
                                <Chip key={i} text={word} color="bg-orange-900 text-orange-200" />
                            ))}
                        </div>
                    </div>
                )}

                {data.grammar_changes && (
                    <div>
                        <span className="text-xs text-slate-500 block mb-1">Grammar & Tone Transformation</span>
                        <div className="text-sm text-slate-300 font-mono bg-slate-900 p-2 rounded">
                            {data.grammar_changes}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Diagnostics;
