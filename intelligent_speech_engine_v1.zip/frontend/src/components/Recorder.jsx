import React, { useState, useEffect, useRef } from 'react';

const Recorder = ({ onAudioData, isConnected }) => {
    const [isRecording, setIsRecording] = useState(false);
    const mediaRecorderRef = useRef(null);
    const audioContextRef = useRef(null);
    const processorRef = useRef(null);
    const streamRef = useRef(null);

    const startRecording = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            streamRef.current = stream;

            audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 16000 });
            const source = audioContextRef.current.createMediaStreamSource(stream);

            // Use ScriptProcessor for raw PCM access (worklet is better but more complex to setup in one file)
            // Buffer size 4096 gives ~250ms chunks at 16kHz
            const processor = audioContextRef.current.createScriptProcessor(4096, 1, 1);
            processorRef.current = processor;

            processor.onaudioprocess = (e) => {
                if (!isConnected) return;

                const inputData = e.inputBuffer.getChannelData(0);
                // Convert float32 to bytes (or just send float32 array)
                // We'll send the raw float32 buffer
                onAudioData(inputData);
            };

            source.connect(processor);
            processor.connect(audioContextRef.current.destination);

            setIsRecording(true);
        } catch (err) {
            console.error("Error accessing microphone:", err);
            alert("Could not access microphone. Please check permissions.");
        }
    };

    const stopRecording = () => {
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
        }
        if (processorRef.current) {
            processorRef.current.disconnect();
        }
        if (audioContextRef.current) {
            audioContextRef.current.close();
        }
        setIsRecording(false);
    };

    return (
        <div className="flex justify-center my-6">
            <button
                onClick={isRecording ? stopRecording : startRecording}
                disabled={!isConnected}
                className={`px-8 py-4 rounded-full text-xl font-bold transition-all shadow-lg ${!isConnected
                        ? 'bg-gray-600 cursor-not-allowed opacity-50'
                        : isRecording
                            ? 'bg-red-500 hover:bg-red-600 animate-pulse'
                            : 'bg-accent hover:bg-blue-600'
                    }`}
            >
                {!isConnected ? 'Connecting...' : isRecording ? 'Stop Dictation' : 'Start Dictation'}
            </button>
        </div>
    );
};

export default Recorder;
