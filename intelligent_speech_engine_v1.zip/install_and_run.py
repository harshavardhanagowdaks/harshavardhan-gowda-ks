import os
import subprocess
import sys
import venv
import time
import threading
import webbrowser

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BACKEND_DIR = os.path.join(BASE_DIR, "backend")
FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")
VENV_DIR = os.path.join(BASE_DIR, "venv")

def run_command(command, cwd=None, shell=True):
    print(f"Running: {command}")
    try:
        subprocess.check_call(command, cwd=cwd, shell=shell)
    except subprocess.CalledProcessError as e:
        print(f"Error running command: {command}")
        sys.exit(1)

def setup_venv():
    if not os.path.exists(VENV_DIR):
        print("Creating virtual environment...")
        venv.create(VENV_DIR, with_pip=True)
    
    # Determine python executable in venv
    if sys.platform == "win32":
        python_exe = os.path.join(VENV_DIR, "Scripts", "python.exe")
        pip_exe = os.path.join(VENV_DIR, "Scripts", "pip.exe")
    else:
        python_exe = os.path.join(VENV_DIR, "bin", "python")
        pip_exe = os.path.join(VENV_DIR, "bin", "pip")

    print("Installing dependencies...")
    run_command(f'"{pip_exe}" install -r requirements.txt', cwd=BASE_DIR)
    
    # Download Spacy model
    print("Downloading Spacy model...")
    run_command(f'"{python_exe}" -m spacy download en_core_web_sm', cwd=BASE_DIR)

    return python_exe

def setup_frontend():
    print("Setting up frontend...")
    if not os.path.exists(os.path.join(FRONTEND_DIR, "node_modules")):
        run_command("npm install", cwd=FRONTEND_DIR)

def run_backend(python_exe):
    print("Starting Backend...")
    # Ensure backend directory is in python path
    env = os.environ.copy()
    env["PYTHONPATH"] = BASE_DIR
    run_command(f'"{python_exe}" -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload', cwd=BASE_DIR)

def run_frontend():
    print("Starting Frontend...")
    run_command("npm run dev", cwd=FRONTEND_DIR)

def main():
    print("--- Intelligent Speech Dictation Engine Setup ---")
    
    python_exe = setup_venv()
    setup_frontend()

    print("\n--- Starting Services ---")
    
    # Start backend in a separate thread/process
    backend_thread = threading.Thread(target=run_backend, args=(python_exe,))
    backend_thread.daemon = True
    backend_thread.start()

    # Give backend a moment to start
    time.sleep(5)

    # Start frontend
    frontend_thread = threading.Thread(target=run_frontend)
    frontend_thread.daemon = True
    frontend_thread.start()

    print("\nSystem is running!")
    print("Backend: http://localhost:8000")
    print("Frontend: http://localhost:5173")
    
    # Open browser
    time.sleep(5)
    webbrowser.open("http://localhost:5173")

    # Keep main thread alive
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Stopping...")

if __name__ == "__main__":
    main()
