# Intelligent Speech Dictation Engine

A real-time, offline, privacy-focused speech dictation engine that polishes your speech into clean, structured text.

## Features

- **Real-time Transcription**: Uses Faster-Whisper for accurate, low-latency speech-to-text.
- **Intelligent Polishing**: Removes filler words (umm, uhh), repetitions, and fixes grammar without LLMs.
- **Tone Control**: Switch between Neutral, Formal, Casual, and Concise modes.
- **100% Offline**: All models run locally on your device. No data leaves your machine.
- **Diagnostics**: See exactly what was changed and why.

## Prerequisites

- Python 3.8+
- Node.js 16+

## Quick Start

1. **Run the Setup Script**:
   Double-click `install_and_run.py` or run it from the terminal:
   ```bash
   python install_and_run.py
   ```
   This script will:
   - Create a virtual environment
   - Install all Python dependencies
   - Download necessary models (Whisper, Spacy, T5)
   - Install Frontend dependencies
   - Start the Backend and Frontend servers
   - Open the application in your browser

## Manual Setup

### Backend
1. Navigate to the project root.
2. Create a virtual environment: `python -m venv venv`
3. Activate it: `venv\Scripts\activate` (Windows) or `source venv/bin/activate` (Linux/Mac)
4. Install dependencies: `pip install -r requirements.txt`
5. Download Spacy model: `python -m spacy download en_core_web_sm`
6. Run server: `uvicorn backend.main:app --reload`

### Frontend
1. Navigate to `frontend/`.
2. Install dependencies: `npm install`
3. Run dev server: `npm run dev`

## Architecture

- **Backend**: FastAPI (Python) handles the WebSocket connection, audio processing, and NLP pipeline.
- **ASR**: `faster-whisper` (tiny.en) for speech recognition.
- **NLP**: `spacy` for tokenization, `transformers` (T5) for grammar/tone.
- **Frontend**: React + Vite + Tailwind CSS for the user interface.

## Troubleshooting

- **Microphone not working**: Ensure your browser has permission to access the microphone. Check if the correct input device is selected in your OS settings.
- **Latency issues**: The first run might be slower as models load into memory. Subsequent requests should be faster. Ensure you are using a machine with decent CPU/RAM.
- **Installation errors**: Make sure you have C++ build tools installed if required by some Python packages (usually pre-compiled wheels are available).

## License

MIT
